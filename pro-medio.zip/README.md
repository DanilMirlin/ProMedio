### *-Unzip*
### *-Using terminal select project folder*
### `npm install`
### `npm start`